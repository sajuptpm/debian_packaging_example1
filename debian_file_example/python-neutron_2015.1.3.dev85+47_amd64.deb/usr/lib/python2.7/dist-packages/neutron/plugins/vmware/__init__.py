import os

NSX_EXT_PATH = os.path.join(os.path.dirname(__file__), 'extensions')
